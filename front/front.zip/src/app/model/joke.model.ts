export interface Joke {
  joke: string;
  response: string;
}
